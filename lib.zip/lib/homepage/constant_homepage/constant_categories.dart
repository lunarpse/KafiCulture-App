// ignore_for_file: constant_identifier_names

import 'package:flutter/material.dart';

const String heading2 = "Handcrafted Curations";
const double heading2_fontSize = 20;
const String categories1 = "Snacks";
const String categories2 = "Drinks";
const String categories3 = "Cookies";
const double categories_fontSize = 17;
const double padding_edge = 8.0;
const int gridView_crossAxisCount = 3;
const double gridView_crossAxisSpacing = 20;
const Color boxShadow_color = Colors.grey;
const double boxShadow_color_opacity = 0.8;
const double boxShadow_blurRadius = 2;
const double boxShadow_spreadRadius = 2;
const double boxShadow_offSet_startPoint = 0;
const double boxShadow_offSet_endPoint = 2;
