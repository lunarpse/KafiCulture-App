enum SingingCharacter { Paytm, Amazonpay }
