const String forgetPwd = "Forget Password";

const String welcomeLogin = "Welcome back, We missed you";

const String userName = "Email/Phone Number";
const String loginTitle = "LOGIN";
const String skipButtonText = "Skip>>";

const String userPassword = "User Password";
const String confirmPassword = "Confirm Password";
const String otp = "OTP";
const String go_back = "Go back";
const String submit = "Submit";

const String registerBtn = "Register";

const String sendotp = "Send OTP";
const String verifyotp = "Verify OTP";

const String registerNow = "Not an user? Register";
const String alreadyaMember = "Already a member? SignIn";
