//appbar
const String apptitle = "KAFICULTURE";
const String appslogan = "Where every cup tells a story";
const String readyToScan = "Ready to Scan";
const String moveTheNFC = "Move the NFC tag to the back of your phone";
const String ok = "OK";
const String dialogTitle = "NFC not enabled or No NFC service";
const String dialogContent =
    "Please enable NFC in your device settings or this device does not support NFC feature.";

//--------------------------------------------------> Cart
//cart-->screen-->cart
const String popular = "Populars";

//cart-->emptycart
const String emptycart = "Cart Is Empty";
const String gotohomepage = "Go To Home";

//cart-->widget-->remove or cancel
const String remove = "Remove";
const String cancel = "Cancel";

//cart-->widget-->bottomscreen
const String billdetails = "Bill Details";
const String checkout = "Check out";
const String subTotal = "Check out";
const String gstString = "Check out";
const String totalString = "Check out";

//cart-->widget-->cart_item
const String cartquantity = "Quantity";

//cart-->widget-->cookinginstructions
const String cookinginstruction = " Add Cooking Instructions";

//cart-->widget-->extraitems
const String extraslogan = "Discover the artistry of flavors";

//-----------------------------------------------> drawerScreen
const String cart = "Cart";
const String home = "Home";
const String categories = "Categories";
const String food = "Food";
const String snacks = "Snacks";
const String drinks = "Drinks";
const String cookies = "Cookies";
const String apparels = "Apparels";
const String apparelsmen = "Men";
const String apparelswomen = "Women";

//-------------------------------------------------------------> Feedbackpage
const String orderconfirmation = "Did You Received Your Order?";
const String yes = "Yes";
const String no = "No";
const String feedbackbox = "Share Your FeedBack Here";
const String feedbackmessage = "Write FeedBack Here....";
const String submit = "Submit";
const String rating = "How Would You Rate Our App?";
const String endrating = "Thank you for your feedback";

//description
const String productdescription =
    "Discover the artistry of flavors, where every sip is a celebration of perfection.";

//homepage
const String offering = "Latest  Offerings";
const String handcrafted = "Handcrafted Curations";
const String populars = "Populars";

//paymentScreen
const String cardpayment = "Credit/Debit Cards";
const String thankyou = "Thank You";
const String selectpaymentmethod = "Select Payment Method";
const String recommended = "Recommended";
const String subtotal = "Sub-Total";
const String totalamount = "Amount: ";
const String orders = "Orders ";
const String payOnDelivery = "Pay On Delivery";

//creditcardwidget
const String validate = "Validate";

//swapwidget
const String loyalitypointequivalent = "Loyality Point Equivalent";
const String hotel1 = "ITC International";
const String hotel2 = "H&M";
const String hotel3 = "Emirates";
const String swapmessage = "Thank you for using SWAP \n Continue with UPI/Card";
const String confirm = "Confirm";
const String otherpaymentmethod = "Other Payment Method";

//dialogbox
const String addon = "Addons";
const String currentitem = "CURRENT ITEM";

//detailspage
const String size = "Size";
const String recommendedproducts = "Customers also liked";
const String buynow = "Buy Now";
const String addtocart = "Add to cart";
const String cartconfirmationmsg = "is added to cart";
const String detailscart = "Cart";
const String continueshopping = "Continue Shopping";
const String detaildescription = "Description";

//extras
const String extraitem1 = "Hot Chocolate";
const String extraitem2 = "Aloo Snacks";
const String extraitem3 = "Dahi Vada";

//------------------------------------------------------------------> Cargo
//Cargo--->men/women--->widget
const String descriptionText = "Description";
const String sizeText1 = "Size - ";
const String sizeText2 = "UK/India";
const String suggestionText = "Customers also liked";
const String buttonName1 = "Buy Now";
const String buttonName2 = "Add To Cart";
const String buttomsheetText = "is addedd to Cart";
const String buttomsheetButtonName1 = "Cart";
const String buttomsheetButtonName2 = "Continue Shopping";
