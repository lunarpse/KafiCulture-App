// import 'dart:convert';

// import 'package:flutter/services.dart';

// import 'package:project_2/delivery/add_model/model.dart';

// Future<Map<String, Person>> loadData() async {
//   final jsonString = await rootBundle.loadString('assets/data.json');
//   final jsonData = json.decode(jsonString) as Map<String, dynamic>;
//   final Map<String, Person> persons = {};

//   jsonData.forEach((key, value) {
//     persons[key] = Person.fromJson(value);
//   });

//   return persons;
// }
